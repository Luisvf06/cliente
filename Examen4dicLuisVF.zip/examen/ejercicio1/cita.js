class Cita{
    constructor(sala,fecha){
        this.sala=sala
        this.fecha=fecha
    }
}